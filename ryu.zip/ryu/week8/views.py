from django.shortcuts import render, redirect
from django.views import View
from django.db.models import *
from django.http import JsonResponse
from .models import *


class EmployeeView(View):

    def get(self, request):
        employee = Employee.objects.all()
        amount = employee.count()
        emp = {"emp": employee,
               "amount" : amount,
               }
        return render(request, "employee.html", emp)

class PositionView(View):

    def get(self, request):
        position = Employee.objects.values('position', 'position__name').annotate(
            amount=Count('position')).order_by('position')
        pos = {"pos": position,
               }
        return render(request, "position.html", pos)

class ProjectView(View):

    def get(self, request):
        project = Project.objects.all()
        pro = {"pro": project,
               }
        return render(request, "project.html", pro)
    
class ProjectEditView(View):

    def get(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        pro = {"pro": project,
               "start_date": project.start_date.strftime("%Y-%m-%d"),
               "due_date": project.due_date.strftime("%Y-%m-%d"),
               }
        return render(request, "project_detail.html", pro)

    def delete(self, request, project_id):
        project = Project.objects.get(pk=project_id)
        project.delete()
        return JsonResponse({"status": "ok"})
    
class StaffEditView(View):

    def put(self, request, project_id, emp_id):
        project = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=emp_id)
        project.staff.add(emp)
        return JsonResponse({"status": "ok"})

    def delete(self, request, project_id, emp_id):
        project = Project.objects.get(pk=project_id)
        emp = Employee.objects.get(pk=emp_id)
        project.staff.remove(emp)
        return JsonResponse({"status": "ok"})