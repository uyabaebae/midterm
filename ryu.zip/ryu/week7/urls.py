from django.urls import path

from . import views

urlpatterns = [
    # ex: /employee/
    path("", views.EmployeeView.as_view(), name="employee"),
    # ex: /employee/position
    path("position/", views.PositionView.as_view(), name="position"),
    # ex: /employee/project
    path("project/", views.ProjectView.as_view(), name="project"),
    # ex: /employee/project/2
    path("project/<int:project_id>/", views.ProjectEditView.as_view(), name="project-edit"),
    # ex: /employee/project/2/2
    path("project/<int:project_id>/<int:emp_id>/", views.StaffEditView.as_view(), name="project-edit"),

]