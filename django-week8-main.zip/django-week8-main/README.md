# Django Templates

- The Django template language [Ref](https://docs.djangoproject.com/en/5.1/ref/templates/language/)
- Built-in template tags and filters [Ref](https://docs.djangoproject.com/en/5.1/ref/templates/builtins/)
- Managing static files [Ref](https://docs.djangoproject.com/en/5.0/howto/static-files/)
- Tutorial
